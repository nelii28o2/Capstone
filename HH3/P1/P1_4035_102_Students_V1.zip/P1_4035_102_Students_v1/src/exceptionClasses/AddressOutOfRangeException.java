package exceptionClasses;

public class AddressOutOfRangeException extends RuntimeException {

	public AddressOutOfRangeException() {
		// TODO Auto-generated constructor stub
	}

	public AddressOutOfRangeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AddressOutOfRangeException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AddressOutOfRangeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
