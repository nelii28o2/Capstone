package exceptionClasses;

public class InvalidAddressException extends RuntimeException {

	public InvalidAddressException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidAddressException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
