
/**
 * A bounded queue implementation for the KCPB Fellow Application
 * @author Daniel Santiago
 */
public class BoundedQueue<E> {

	private Node<E> head;
	private Node<E> tail;
	private int size;
	private int maxSize;
	
	
	/**
	 * Queue constructor
	 * @param maxSize - Maximum sixe of the queue
	 */
	public BoundedQueue(int maxSize) {
		
	}

	/**
	 * @return true is the queue contains no elements
	 */
	public boolean isEmpty() {
		
	}
	
	/**
	 * @return the number of elements in the queue
	 */
	public int size() {
		
	}
	
	/**
	 * @return true if the queue is full
	 */
	public boolean isFull() {
		
	}
	
	/**
	 * @return the maximum size of the queue
	 */
	public int getMaxSize() {
		
	}
	
	/**
	 * Inserts an element into the back of the queue
	 * @param e element to insert into queue, throws Runtime Exception if queue is full
	 */
	public void enqueue(E e) {
		if(size == maxSize) {
			throw new RuntimeException("Queue is full, size = " + size);
		}
		
		
	}
	
	/**
	 * Removes the element in front of the queue, throws Runtime Exception if queue is empty
	 * @return the element removed from the front of the queue
	 */
	public E dequeue() {
		if (size == 0) {
			throw new RuntimeException("Queue is empty");
		}
		
		
	}
	
	/**
	 * Gets the element currently in front of the queue, throws Runtime Exception if queue is empty.
	 * @return the element in front of the queue
	 */
	public E peek() {
		if (size == 0) {
		 throw new RuntimeException("Queue is empty");
		}
		
	}
	
	public String toString() {
		
	}
	
	private class Node<E> {
		private E element;
		private Node<E> next;
		
		public Node(E element) {
			super();
			this.element = element;
		}
		
		public E getElement() {
			return element;
		}
		
		public void setElement(E element) {
			this.element = element;
		}
		
		public Node<E> getNext() {
			return next;
		}
		
		public void setNext(Node<E> next) {
			this.next = next;
		}
	}
}
